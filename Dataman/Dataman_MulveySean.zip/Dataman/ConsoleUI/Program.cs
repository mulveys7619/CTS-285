﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using ClassLibrary;

namespace ConsoleUI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            bool valid;
            do
            {
                valid = true;
                Console.WriteLine(StandardMessages.StartMenu());

                switch (Console.ReadLine())
                {
                    case "1":
                        AnswerChecker.RunAC();
                        break;
                    case "2":
                        Console.WriteLine("TODO: FIX ANSWER TRACKER");
                        MemoryBank.RunMB();
                        break;
                    case "3":
                        NumberGuesser.RunNG();
                        break;
                    case "4":
                        WipeOut.RunWO();
                        break;
                    default:
                        Console.WriteLine("ERROR: PICK A VALID CHOICE!");
                        valid = false;
                        break;
                }
            } while (valid == false);


            Console.ReadLine();
        }
    }
}
