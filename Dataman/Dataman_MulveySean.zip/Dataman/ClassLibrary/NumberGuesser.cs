﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class NumberGuesser
    {
        
        public static void RunNG()
        {
            Random random = new Random();
            int num = random.Next(100);
            int userNum;
            int count = 0;
            do
            {
                count++;

                Console.WriteLine("Enter a number: ");
                while (!int.TryParse(Console.ReadLine(), out userNum))
                {
                    Console.WriteLine("ERROR: INVALID INPUT!");
                }
                if (userNum < num)
                {
                    Console.WriteLine("Number is too small!");
                }
                else if(userNum > num)
                {
                    Console.WriteLine("Number is too large!");
                }
            } while (userNum != num);
            Console.WriteLine("Correct! \nNumber of guesses: "+ count);
        }
    }
}
