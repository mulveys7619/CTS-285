﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string StartMenu()
        {
            return "         Dataman         \n" +
                  "=========================\n" +
                  "1. Answer Checker\n" +
                  "2. Memory Bank\n" +
                  "3. Number Guesser\n" +
                  "4. Wipe Out\n" +
                  "Enter an option above (1-4): ";

        }
        public static string AskfForAC(int i)
        {
            return "Enter equation number " + i + ".";
        }
        public static string AskforMB(int i)
        {
            return "Question " + i;
        }
        public static string WrongAnswer()
        {
            return "EEE";
        }
        public static string TooLarge()
        {
            return "ERROR: Result Too Large! Must Be Under 1000!";
        }
        public static string TooSmall()
        {
            return "ERROR: Result Too Small! Must Be Greater Than -1!";
        }
    }
}
