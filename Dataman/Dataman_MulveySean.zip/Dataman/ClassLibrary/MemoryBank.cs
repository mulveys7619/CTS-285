﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class MemoryBank
    {
        
        public static int GenerateFirstNum()
        {
            Random random = new Random();
            int first = random.Next(1, 99);
            return first;
        }
        public static int GenerateSecondNum()
        {
            Random random = new Random();
            int second = random.Next(99);
            return second;
        }
        public static char GenerateOperator()
        {
            Random random = new Random();
            switch(random.Next(1,4))
            {
                case 1:
                    return '+';
                    
                case 2:
                    return '-';
                case 3:
                    return '*';
                case 4:
                    return '/';
                default:
                    return ' ';

            }
        }
        public static int GetAnswer(int first, int second, char op)
        {
            Random random = new Random();
            int result = 0;
            switch(op)
            {
                case '+':
                    result = first + second;
                    while (result > 1000)
                    {
                        first = random.Next(1,99);
                        second = random.Next(99);
                        result = first + second;
                    }
                    break;
                case '-':
                    result = first - second;
                    while (result < 0)
                    {
                        first = random.Next(1, 99);
                        second = random.Next(99);
                        result = first - second;
                    }
                    break;
                case '*':
                    result = first * second;
                    while (result > 1000)
                    {
                        first = random.Next(10);
                        second = random.Next(99);
                        result = first * second;
                    }
                    break;
                case '/':
                    result = first / second;
                    
                    break;
            }
            return result;
        }
        public static void DisplayQuestion(int first, int second, char op)
        {
            Console.WriteLine(first + " " + op + " " + second);
        }
       
        public static void RunMB()
        {
            Random random = new Random();
            int user;
            int right = 0;
            int wrong = 0;
            bool good = true;
            int first = random.Next(1,99);
            int second = random.Next(1, 99);
            char op = GenerateOperator();
            int real = GetAnswer(first, second, op);
            for (int i = 0; i < 10; i++)
            {
                do
                {
                    first = random.Next(1, 99);
                    second = random.Next(1, 99);
                    switch (random.Next(1, 4))
                    {
                        case 1:
                            op = '+';
                            break;
                        case 2:
                            op = '-';
                            break;
                        case 3:
                            op = '*';
                            break;
                        case 4:
                            op = '/';
                            break;
                        default:
                            op = ' ';
                            break;

                    }
                    switch (op)
                    {
                        case '+':
                            real = first + second;
                            while (real > 1000)
                            {
                                first = random.Next(1, 99);
                                second = random.Next(99);
                                real = first + second;
                            }
                            break;
                        case '-':
                            real = first - second;
                            while (real < 0)
                            {
                                first = random.Next(1, 99);
                                second = random.Next(99);
                                real = first - second;
                            }
                            break;
                        case '*':
                            real = first * second;
                            while (real > 1000)
                            {
                                first = random.Next(10);
                                second = random.Next(99);
                                real = first * second;
                            }
                            break;
                        case '/':
                            real = first / second;

                            break;
                    }
                    Console.WriteLine(StandardMessages.AskforMB(i + 1));
                    DisplayQuestion(first, second, op);
                    string userStr = Console.ReadLine();

                    if (int.TryParse(userStr, out user) == true)
                    {
                        user = int.Parse(userStr);
                    }
                    else
                    {
                        Console.WriteLine("ERROR: INVALID INPUT");
                        good = false;
                    }
                    if (user == real)
                    {
                        right++;
                    }
                    else
                    {
                        wrong++;
                    }



                } while (good == false);
                
                
                real = GetAnswer(first, second, op);
                
            }
            Console.WriteLine("Correct: " + right);
            Console.WriteLine("Attempts: " + (right + wrong));
        }

    }
}
