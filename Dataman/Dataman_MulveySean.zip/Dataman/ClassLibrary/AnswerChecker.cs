﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ClassLibrary
{
    public class AnswerChecker
    {
        public static string EnterEquations(int i)
        {
          
            Console.WriteLine(StandardMessages.AskfForAC(i + 1));
            string userEquation = Console.ReadLine();
            return userEquation;
            
        }
        public static int GetFirstNum(string str, char op)
        {
            List<string> firstNumList = new List<string>();
            int firstNum;
            for (int i = 0; i < str.Length;i++)
            {
                char character = str[i];

                int.TryParse(character.ToString(), out firstNum);
                firstNumList.Add(character.ToString());
  
            }
            string listJoinStr = string.Join(",", firstNumList);
            int.TryParse(listJoinStr, out firstNum);
            string firstNumStr = str.Split(new string[] { op.ToString() }, StringSplitOptions.None)[0];
            firstNum = int.Parse(firstNumStr);
            return firstNum;
        }
        public static char GetOperator(string str)
        {
            char op;
            int check;

            for (int i = 0; i < str.Length; i++)
            {
                if (int.TryParse(str[i].ToString(), out check) == false)
                {
                    op = str[i];

                    return op;
                }
                
            }
            return '*';
        }
        public static int GetSecondNum(string str, char op)
        {
            int secondNum;
            string secondNumStr = " ";
            for (int i = 0; i < str.Length; i++)
            {
                char character = str[i];
                
                if (int.TryParse(str, out secondNum) == false)
                {
                    secondNumStr = str.Split(new string[] {op.ToString()}, StringSplitOptions.None)[1].Split('=')[0].Trim();
                    break;
                }
            }
            secondNum = int.Parse(secondNumStr);
            return secondNum;
        }

        public static int CompareOperators(int first, int second, char op)
        {
            
            switch (op)
            {
                case '+':
                    return Add(first, second);
                    
                case '-':
                    return Subtract(first, second);
                    
                case '/':
                    Console.WriteLine("r" + Remainder(first, second));
                    return Divide(first, second);
                    
                case '*':
                    return Multiply(first, second);
                    
                case 'x':
                    return Multiply(first, second);
                    
                default:
                    return -1000;


            }
        }
        public static int Add(int first, int second)
        {
            int result = first + second;
            return result;
        }
        public static int Multiply(int first, int second)
        {
            int result = first * second;
            return result;
        }
        public static int Subtract(int first, int second)
        {
            int result = first - second;
            return result;
        }
        public static int Divide( int first, int second)
        {
            int result = first / second;
            return result;
        }
        public static int Remainder(int first, int second)
        {
            int rem = first % second;
            return rem;
        }
        public static int UserAnswer(string userString)
        {
            string userStr = userString.Split('=')[1];
            int user = int.Parse(userStr);
            return user;
        }
        
        public static void RunAC()
        {
            int right = 0;
            int wrong = 0;
            for (int i = 0; i < 10; i++)
            {
                StandardMessages.AskforMB(i + 1);
                string str = EnterEquations(i).Replace(" ","");
                char op = GetOperator(str);
                int second = GetSecondNum(str, op);
                int first = GetFirstNum(str,op);
                int real = CompareOperators(first, second, op);

                int user = UserAnswer(str);

                if (user >= 1000 || real >= 1000)
                {
                    Console.WriteLine(StandardMessages.TooLarge());
                    

                }
                else if (user < 0 || real < 0)
                {
                    Console.WriteLine(StandardMessages.TooSmall());
                    

                }
                else if (user == real)
                {
                    right++;
                    
                }
                else
                {
                    wrong++;
                    Console.WriteLine(StandardMessages.WrongAnswer());
                    
                }
            }
            Console.WriteLine("Correct: " + right);
            Console.WriteLine("Attempts: " + (right + wrong));
            
        }
    }
}
