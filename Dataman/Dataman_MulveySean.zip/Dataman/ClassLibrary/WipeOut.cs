﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace ClassLibrary
{
    public class WipeOut
    {
        static int seconds = 0;

        public static void RunWO()
        {
            int answer = 0;
            string userStr;
            int user = 0;
            int count = 0;
            Random random = new Random();
            Timer time = new Timer();
            time.Elapsed += new ElapsedEventHandler(OnTimedEvent);
            time.Interval = 1000;
            time.Enabled = true;

           
                do
                {
                    Console.Clear();
                    time.Elapsed += new ElapsedEventHandler(OnTimedEvent);
                    Random number = new Random();
                    int number1 = number.Next(1, 31);
                    int number2 = number.Next(1, 31);
                    int operators = number.Next(1, 5);  
                    Console.WriteLine("\tMath Problems\n");

                    switch (operators)
                    {
                        case 1:
                            answer = number1 + number2;
                            Console.WriteLine(number1 + "+" + number2);
                            userStr = Console.ReadLine();
                            break;
                        case 2:
                            answer = number1 - number2;
                            Console.WriteLine(number1 + "-" + number2);
                            userStr = Console.ReadLine();
                        break;
                        case 3:
                            answer = number1 * number2;
                            Console.WriteLine(number1 + "*" + number2);
                            userStr = Console.ReadLine();
                        break;
                        case 4:
                            answer = number1 / number2;
                            Console.WriteLine(number1 + "/" + number2);
                            userStr = Console.ReadLine();
                        break;
                        default:
                        userStr = "000";
                            break;


                    }
                user = int.Parse(userStr);


                    count++;
                } while (seconds != random.Next(15, 30) || user != answer);
                Console.WriteLine("Number of Problems completed: "+ count);

                
            

        }
        private static void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            seconds++;
        }
    }
}
