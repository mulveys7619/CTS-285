﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        // Create Menu
        public static String MainMenu()
        {
            
            return "Welcome to the calculator program\n" +
             "1. Add\n" +
             "2. Subtract\n" +
             "3. Divide\n" +
             "4. Multiply\n" +
             "5. Exit";
        }
        public static String InputError()
        {
            return "ERROR: PLEASE INPUT A VALID VALUE";
        }
        public static String InputNum()
        {
            return "Enter a number: ";
        }
        public static String DisAdd(double num1, double num2, double sum)
        {
            return num1 + " + " + num2 + " = " + sum;
        }
        public static String DisSubtract(double num1, double num2, double diff)
        {
            return num1 + " - " + num2 + " = " + diff;
        }
        public static String DisDivide(double num1, double num2, double div)
        {
            return num1 + " / " + num2 + " = " + div;
        }
        public static String DisMultiply(double num1, double num2, double product)
        {
            return num1 + " * " + num2 + " = " + product;
        }
        
        public static String DisRepeat()
        {
            return "1. Repeat\n" +
                   "2. Main Menu\n" +
                   "3. Exit";
        }
        public static String DisExit()
        {
            return "Goodbye.";
        }

    }
}
