﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace M1HW1_MulveySean
{
    class Program
    {
        static void Main(string[] args)
        {
            // Call Menu from StandardMessages
            Console.WriteLine(StandardMessages.MainMenu());

            // Get userChoice
            string userChoice = Console.ReadLine();


            // Create switch for userChoice
            switch (userChoice)
            {
                // case 1: call Add()
                case "1":
                    Add();
                    break;
                // case 2: call Subtract()
                case "2":
                    Subtract();
                    break;
                // case 3: call Divide()
                case "3":
                    Divide();
                    break;
                // case 4: call Multiply()
                case "4":
                    Multiply();
                    break;
                // case 5: call Exit()
                case "5":
                    Exit();
                    break;
                // Default: Output error and redisplay menu
                default:
                    StandardMessages.InputError();
                    break;
            }
        }
        // Create Add()
        public static void Add()
        {
            double num1 = 0;
            double num2 = 0;
            double sum;
            Console.WriteLine(StandardMessages.InputNum());

            // TODO: USE DIFFERENT METHOD
            num1 = DoubleValidation(num1);

            Console.WriteLine(StandardMessages.InputNum());
            // TODO: USE DIFFERENT METHOD
            num2 = DoubleValidation(num2);
            sum = num1 + num2;
            // Display Results
            Console.WriteLine(StandardMessages.DisAdd(num1, num2, sum));

            // Call Repeat
            Repeat(Add);

        }

        // Create Subtract()
        public static void Subtract()
        {
            double num1 = 0;
            double num2 = 0;
            double diff;
            Console.WriteLine(StandardMessages.InputNum());

            // TODO: USE DIFFERENT METHOD
            num1 = DoubleValidation(num1);

            Console.WriteLine(StandardMessages.InputNum());
            // TODO: USE DIFFERENT METHOD
            num2 = DoubleValidation(num2);
            diff = num1 - num2;
            // Display Results
            Console.WriteLine(StandardMessages.DisSubtract(num1, num2, diff));

            // Call Repeat
            Repeat(Subtract);
        }

        // Create Divide()
        public static void Divide()
        {
            double num1 = 0;
            double num2 = 0;
            double div;
            Console.WriteLine(StandardMessages.InputNum());

            // TODO: USE DIFFERENT METHOD
            num1 = DoubleValidation(num1);

            Console.WriteLine(StandardMessages.InputNum());
            // TODO: USE DIFFERENT METHOD
            num2 = DoubleValidation(num2);
            div = num1 / num2;
            // Display Results
            Console.WriteLine(StandardMessages.DisDivide(num1, num2, div));

            // Call Repeat
            Repeat(Divide);
            
        }

        // Create Multiply()
        public static void Multiply()
        {
            double num1 = 0;
            double num2 = 0;
            double product;
            Console.WriteLine(StandardMessages.InputNum());

            // TODO: USE DIFFERENT METHOD
            num1 = DoubleValidation(num1);

            Console.WriteLine(StandardMessages.InputNum());
            // TODO: USE DIFFERENT METHOD
            num2 = DoubleValidation(num2);
            product = num1 * num2;
            // Display Results
            Console.WriteLine(StandardMessages.DisMultiply(num1, num2, product));

            // Call Repeat
            Repeat(Multiply);
        }
        // Create Exit()
        public static void Exit()
        {
            Console.WriteLine(StandardMessages.DisExit());
            Console.ReadLine();
        }

        // Create Repeat()
        public static void Repeat(Action currFunc)
        {
            // Create bool for do while loop
            bool check = true;
            do
            {
                // Display repeat menu
                Console.WriteLine(StandardMessages.DisRepeat());
                // Get user input
                switch (Console.ReadLine())
                {
                    case "1":
                        currFunc();
                        break;
                    case "2":
                        Main(null);
                        break;
                    case "3":
                        Exit();
                        break;
                    default:
                        Console.WriteLine(StandardMessages.InputError());
                        check = false;
                        break;


                }
                // If invalid input, redisplay
            } while (check == false);
        }

        // Create Validation()
        public static double DoubleValidation(double num)
        {
            while (!double.TryParse(Console.ReadLine(), out num))
            {
                Console.WriteLine(StandardMessages.InputError());
            }

            return num;
        }
        // TODO: PUT DO/WHILE IN REPEAT AND PASS CURRENT METHOD AS PARAMETER FOR IF THEY CHOOSE 1
    }
}
